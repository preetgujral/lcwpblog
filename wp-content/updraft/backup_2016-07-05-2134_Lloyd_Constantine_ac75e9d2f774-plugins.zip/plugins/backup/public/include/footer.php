<!--<div class="sg-footer">
    <div class="row">
        <div class="col-md-12">
            <strong><?php _t('Powered by Backup Guard')?></strong>
            <p>
                <a href="javascript:void(0)" data-toggle="modal" data-modal-name="terms" data-remote="modalTerms"><?php _t('Terms & Conditions')?></a> | <a href="#" data-toggle="modal" data-modal-name="privacy" data-remote="modalPrivacy"><?php _t('Privacy Policy')?></a>
                <strong class="sg-version"><?php _t('v.1.0.0')?></strong>
            </p>
        </div>
    </div>
</div>-->
<?php require_once(SG_PUBLIC_INCLUDE_PATH.'modal.php'); ?>
</div>
<div class="clearfix"></div>
</div>
<!-- /#sg-wrapper -->
<script type="text/javascript">
    less = {
        env: "production",
    };
</script>
